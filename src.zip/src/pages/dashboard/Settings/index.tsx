import { SettingsContent } from './components/SettingsContent';

export const Settings = () => {
  return <SettingsContent />;
};
