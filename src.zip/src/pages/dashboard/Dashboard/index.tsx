import { DashboardContent } from './components/DashboardContent';

export const Dashboard = () => {
  return <DashboardContent />;
};
